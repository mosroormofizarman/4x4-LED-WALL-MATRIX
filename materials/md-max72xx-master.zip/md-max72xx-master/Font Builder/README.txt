The file txt2font.executable is a windows .exe file. Please rename if you want to run this, otherwise you can simply remake the executable.

Arduino library manager policy prevents a .exe file from being part of the distribution.
