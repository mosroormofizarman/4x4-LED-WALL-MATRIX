#include <stdbool.h>

bool mgos_arduino_md_max72xx_init(void) {
  return true;
}
